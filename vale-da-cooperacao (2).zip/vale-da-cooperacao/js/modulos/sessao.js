import { Store } from "./store.js";
import { Salas } from "./salas.js";
import { Jogo } from "./jogo.js";

// Guarda quem eu sou neste aparelho, pra reconectar depois de F5 ou queda do Wi-Fi.
export const Sessao = {
  salvar(codigo, id){ Store.set("vale:sessao", { codigo, id }); },
  ler(){ return Store.get("vale:sessao"); },
  tentarReconectar(){
    const ss = this.ler();
    if(!ss) return null;
    const s = Salas.carregar(ss.codigo);
    if(s && Jogo.reconectar(s, ss.id)){ Salas.salvar(s); return s; }
    return null;
  }
};
