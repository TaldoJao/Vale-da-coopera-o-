import { Store } from "./store.js";

// Guarda ações feitas sem internet e manda quando a conexão voltar.
export const Offline = {
  fila: Store.get("vale:fila", []),
  empurrar(acao){
    if(!navigator.onLine){ this.fila.push(acao); Store.set("vale:fila", this.fila); }
  },
  descarregar(enviar){
    const f = this.fila;
    this.fila = [];
    Store.set("vale:fila", []);
    f.forEach(enviar); // troca "enviar" pela chamada ao banco
    return f.length;
  }
};
