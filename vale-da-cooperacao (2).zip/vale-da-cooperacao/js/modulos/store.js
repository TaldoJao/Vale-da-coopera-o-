// Camada de armazenamento. Hoje usa localStorage.
// Quando o grupo escolher o banco (Firebase, Supabase...), troca só este arquivo.
export const Store = {
  get(k, padrao = null){
    try{ const v = localStorage.getItem(k); return v ? JSON.parse(v) : padrao; }
    catch(e){ return padrao; }
  },
  set(k, v){
    try{ localStorage.setItem(k, JSON.stringify(v)); }
    catch(e){ console.warn("Store cheio ou bloqueado", e); }
  },
  del(k){ try{ localStorage.removeItem(k); }catch(e){} },
  chaves(prefixo){
    const r = [];
    try{
      for(let i = 0; i < localStorage.length; i++){
        const k = localStorage.key(i);
        if(k && k.startsWith(prefixo)) r.push(k);
      }
    }catch(e){}
    return r;
  }
};
