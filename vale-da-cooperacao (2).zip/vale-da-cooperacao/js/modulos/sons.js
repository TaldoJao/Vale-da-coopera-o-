import { Store } from "./store.js";

// Se o mp3 não carregar, toca um bipe gerado no navegador.
const SONS = {
  pular:      { src: "assets/sons/pular.mp3", freq: 330 },
  reconectar: { src: "assets/sons/reconectar.mp3", freq: 660 },
  vez:        { src: "assets/sons/vez.mp3", freq: 520 },
  fim:        { src: "assets/sons/fim.mp3", freq: 220 }
};

export const Som = {
  mudo: Store.get("vale:mudo", false),
  ctx: null,
  bipe(freq){
    try{
      this.ctx = this.ctx || new (window.AudioContext || window.webkitAudioContext)();
      const o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = "square"; o.frequency.value = freq; g.gain.value = 0.06;
      o.connect(g); g.connect(this.ctx.destination);
      o.start(); o.stop(this.ctx.currentTime + 0.15);
    }catch(e){}
  },
  tocar(nome){
    if(this.mudo || !SONS[nome]) return;
    try{
      new Audio(SONS[nome].src).play().catch(() => this.bipe(SONS[nome].freq));
    }catch(e){ this.bipe(SONS[nome].freq); }
  },
  alternar(){
    this.mudo = !this.mudo;
    Store.set("vale:mudo", this.mudo);
    return this.mudo;
  }
};
