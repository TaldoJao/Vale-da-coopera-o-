// Lógica de turnos. Sem acesso a tela nem a banco, então é fácil de testar.
export const Jogo = {
  addJogador(s, nome){
    const j = { id: "j" + Date.now().toString(36) + Math.floor(Math.random() * 99), nome, conectado: true };
    s.jogadores.push(j);
    return j;
  },
  // Avança pro próximo jogador CONECTADO. Quem caiu é pulado sozinho.
  proximaVez(s){
    const n = s.jogadores.length;
    if(!n) return null;
    for(let i = 1; i <= n; i++){
      const idx = (s.vez + i) % n;
      if(s.jogadores[idx].conectado){
        if(idx <= s.vez) s.rodada++;
        s.vez = idx;
        return s.jogadores[idx];
      }
    }
    return null;
  },
  // Botão "Pular vez": só quem está na vez (ou o anfitrião) pode usar.
  pularVez(s, quemPediuId, ehAnfitriao = false){
    const atual = s.jogadores[s.vez];
    if(!atual) return { ok: false, erro: "Sala sem jogadores." };
    if(atual.id !== quemPediuId && !ehAnfitriao) return { ok: false, erro: "Não é a sua vez." };
    const prox = this.proximaVez(s);
    return prox ? { ok: true, de: atual, para: prox } : { ok: false, erro: "Ninguém conectado." };
  },
  desconectar(s, id){
    const j = s.jogadores.find(x => x.id === id);
    if(!j) return false;
    j.conectado = false;
    if(s.jogadores[s.vez] && s.jogadores[s.vez].id === id) this.proximaVez(s); // não trava o jogo
    return true;
  },
  // Botão "Reconectar jogador": volta com o mesmo id, sem perder o lugar.
  reconectar(s, id){
    const j = s.jogadores.find(x => x.id === id);
    if(!j) return false;
    j.conectado = true;
    return true;
  }
};
