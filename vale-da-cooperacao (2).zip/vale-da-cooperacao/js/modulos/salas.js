import { Store } from "./store.js";

const SALA_TTL = 24 * 60 * 60 * 1000; // 24h sem atividade = sala apagada

export const Salas = {
  chave: c => "vale:sala:" + c,
  criar(codigo){
    const s = { codigo, jogadores: [], vez: 0, rodada: 1, ativa: Date.now() };
    Store.set(this.chave(codigo), s);
    return s;
  },
  carregar(codigo){ return Store.get(this.chave(codigo)); },
  salvar(s){ s.ativa = Date.now(); Store.set(this.chave(s.codigo), s); },
  // Apaga salas velhas. Retorna quantas foram apagadas.
  limpar(){
    let n = 0;
    Store.chaves("vale:sala:").forEach(k => {
      const s = Store.get(k);
      if(!s || Date.now() - s.ativa > SALA_TTL){ Store.del(k); n++; }
    });
    return n;
  }
};
