// Se o arquivo falhar, aparece o emoji no lugar. Ajusta os caminhos pros arquivos reais.
export const IMG = {
  logo:        ["assets/imagens/logo.png", "🏡"],
  vila0:       ["assets/imagens/vila-0.png", "🌱"],
  vila5:       ["assets/imagens/vila-5.png", "🏘️"],
  agricultor:  ["assets/imagens/agricultor.png", "🌾"],
  artesao:     ["assets/imagens/artesao.png", "🏺"],
  pescador:    ["assets/imagens/pescador.png", "🐟"],
  comerciante: ["assets/imagens/comerciante.png", "🛒"]
};

export function criarImagem(chave, alt){
  const [src, emoji] = IMG[chave] || ["", "❔"];
  const el = new Image();
  el.alt = alt || chave;
  el.onerror = () => {
    const s = document.createElement("span");
    s.className = "fallback";
    s.textContent = emoji;
    s.title = el.alt;
    el.replaceWith(s);
  };
  el.src = src;
  return el;
}
