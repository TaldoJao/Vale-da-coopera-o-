import { Store } from "./store.js";

export const Cronometro = {
  id: null,
  ligado: Store.get("vale:cron", false),
  segundos: 30,
  iniciar(aoMudar, aoAcabar){
    this.parar();
    if(!this.ligado) return aoMudar(null);
    let resta = this.segundos;
    aoMudar(resta);
    this.id = setInterval(() => {
      resta--;
      aoMudar(resta);
      if(resta <= 0){ this.parar(); aoAcabar(); }
    }, 1000);
  },
  parar(){ clearInterval(this.id); this.id = null; },
  alternar(){
    this.ligado = !this.ligado;
    Store.set("vale:cron", this.ligado);
    if(!this.ligado) this.parar();
    return this.ligado;
  }
};
