import { Salas } from "./modulos/salas.js";
import { Jogo } from "./modulos/jogo.js";
import { Sessao } from "./modulos/sessao.js";
import { criarImagem } from "./modulos/imagens.js";
import { Som } from "./modulos/sons.js";
import { Cronometro } from "./modulos/cronometro.js";
import { Offline } from "./modulos/offline.js";

const $ = id => document.getElementById(id);
const nomes = ["Ana", "Bruno", "Carla", "Davi", "Eva", "Caio"];
let sala = null, euId = null;

function log(t){
  const l = $("log");
  l.textContent = new Date().toLocaleTimeString("pt-BR") + "  " + t + "\n" + l.textContent;
}

function desenhar(){
  $("cod").textContent = sala.codigo;
  $("rod").textContent = sala.rodada;
  $("jogadores").innerHTML = "";
  sala.jogadores.forEach((j, i) => {
    const r = document.createElement("div");
    r.className = "row" + (i === sala.vez ? " vez" : "");
    const nome = document.createElement("span");
    nome.textContent = (i === sala.vez ? "▶ " : "") + j.nome;
    if(!j.conectado) nome.className = "off";
    const b = document.createElement("button");
    b.className = "sec";
    b.textContent = j.conectado ? "Derrubar" : "Reconectar";
    b.onclick = () => {
      if(j.conectado){ Jogo.desconectar(sala, j.id); log(j.nome + " caiu. Vez passou pro próximo."); }
      else { Jogo.reconectar(sala, j.id); Som.tocar("reconectar"); log(j.nome + " voltou pra sala."); }
      Salas.salvar(sala);
      Offline.empurrar({ tipo: "conexao", id: j.id });
      desenhar(); reiniciarTempo();
    };
    r.append(nome, b);
    $("jogadores").appendChild(r);
  });
  $("bTimer").textContent = "⏱ Cronômetro: " + (Cronometro.ligado ? "on" : "off");
  $("bMudo").textContent = Som.mudo ? "🔇 Som: off" : "🔊 Som: on";
}

function reiniciarTempo(){
  Cronometro.iniciar(
    s => { $("tempo").textContent = s === null ? "" : "⏱ " + s + "s"; },
    () => {
      log("Tempo esgotado. Vez passou sozinha.");
      Jogo.proximaVez(sala); Salas.salvar(sala);
      Som.tocar("pular"); desenhar(); reiniciarTempo();
    }
  );
}

$("bAdd").onclick = () => {
  const n = sala.jogadores.length;
  const j = Jogo.addJogador(sala, nomes[n % nomes.length] + (n >= nomes.length ? n : ""));
  if(!euId){ euId = j.id; Sessao.salvar(sala.codigo, euId); }
  Salas.salvar(sala); desenhar();
};
$("bPular").onclick = () => {
  const res = Jogo.pularVez(sala, euId, true); // na demo o anfitrião pula por qualquer um
  if(!res.ok){ log("Não rolou: " + res.erro); return; }
  Som.tocar("pular");
  log(res.de.nome + " pulou. Agora é " + res.para.nome + ".");
  Salas.salvar(sala); Offline.empurrar({ tipo: "pular" });
  desenhar(); reiniciarTempo();
};
$("bTimer").onclick = () => { Cronometro.alternar(); desenhar(); reiniciarTempo(); };
$("bMudo").onclick = () => { Som.alternar(); desenhar(); };
$("bLimpa").onclick = () => log(Salas.limpar() + " sala(s) antiga(s) apagada(s).");

function checarRede(){ $("banner").style.display = navigator.onLine ? "none" : "block"; }
window.addEventListener("offline", () => { checarRede(); log("Ficou offline."); });
window.addEventListener("online", () => {
  checarRede();
  const n = Offline.descarregar(a => console.log("enviando", a));
  log("Voltou a internet. " + n + " ação(ões) sincronizada(s).");
});

// início
Salas.limpar();
sala = Sessao.tentarReconectar();
if(sala){ euId = Sessao.ler().id; log("Reconectado na sala " + sala.codigo + "."); }
else { sala = Salas.criar("VALE" + Math.floor(100 + Math.random() * 900)); }
["logo", "vila0", "vila5", "agricultor", "artesao", "pescador", "comerciante"]
  .forEach(k => $("imgs").appendChild(criarImagem(k)));
checarRede(); desenhar(); reiniciarTempo();

if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
