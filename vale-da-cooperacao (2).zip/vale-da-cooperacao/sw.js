// Service worker: guarda os arquivos do jogo pra abrir sem internet.
// Sempre que mudar algum arquivo, aumenta o número do CACHE.
const CACHE = "vale-v1";
const ARQUIVOS = [
  "./", "index.html", "css/style.css", "js/main.js",
  "js/modulos/store.js", "js/modulos/salas.js", "js/modulos/jogo.js",
  "js/modulos/sessao.js", "js/modulos/imagens.js", "js/modulos/sons.js",
  "js/modulos/cronometro.js", "js/modulos/offline.js"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ARQUIVOS)));
  self.skipWaiting();
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener("fetch", e => {
  if(e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request).then(cacheado =>
      cacheado || fetch(e.request).then(res => {
        const copia = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, copia));
        return res;
      }).catch(() => cacheado)
    )
  );
});
