# Vale da Cooperação

Jogo cooperativo de estratégia pra navegador (HTML/CSS/JS). Este repositório tem os módulos da Pessoa 3: programação e integração.

## Como rodar

Os módulos usam `import`, então abrir o `index.html` com duplo clique não funciona. Use um servidor local:

- VS Code: extensão **Live Server** → botão direito no `index.html` → *Open with Live Server*
- ou no terminal: `python3 -m http.server 8000` e abre `http://localhost:8000`

Pra testar com os 4 celulares, publica no **GitHub Pages** (Settings → Pages → branch `main`).

## Estrutura

```
index.html            página principal (demo)
sw.js                 modo offline (cache dos arquivos)
css/style.css         estilos
js/main.js            liga os módulos na tela (parte de demo)
js/modulos/
  store.js            armazenamento (trocar aqui quando escolher o banco)
  salas.js            criar/salvar sala e limpar salas antigas (24h)
  jogo.js             turnos: pular vez, desconectar, reconectar
  sessao.js           lembra quem sou eu pra reconectar depois de F5
  imagens.js          imagens com emoji de reserva se o arquivo falhar
  sons.js             efeitos sonoros + botão de silenciar
  cronometro.js       cronômetro opcional por vez
  offline.js          fila de ações feitas sem internet
assets/imagens/       PNGs da Pessoa 1 (nomes em js/modulos/imagens.js)
assets/sons/          sons da Pessoa 4 (nomes em js/modulos/sons.js)
```

## Pendências

- [ ] Trocar o `Store` pelo banco real
- [ ] Inserir a história e os textos da Pessoa 2
- [ ] Colocar as imagens e os sons nas pastas `assets/`
- [ ] Modo plateia (só se sobrar tempo)

## Regras do grupo (Git)

- Ninguém commita direto na `main`. Cada tarefa tem uma branch: `arte/personagens`, `texto/eventos`, `codigo/pular-vez`, `teste/sons`.
- Commits curtos no imperativo: `Adiciona botão de pular vez`.
- Abre um Pull Request, outra pessoa revisa, a Pessoa 3 faz o merge, a Pessoa 4 testa.
- Nomes de arquivo em minúsculo, sem espaço e sem acento: `vila-0.png`, não `Vila 0.PNG`.
