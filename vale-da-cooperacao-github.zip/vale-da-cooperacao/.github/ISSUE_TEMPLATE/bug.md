---
name: Problema encontrado
about: Algo deu errado durante um teste
title: "[Bug] "
labels: bug
---

**O que aconteceu:**

**O que era pra acontecer:**

**Como repetir:**
1.
2.

**Aparelho e navegador:** (ex.: Samsung A54, Chrome)
**Print ou vídeo:**
