---
name: Tarefa
about: Uma entrega do projeto
title: "[Pessoa X] "
labels: tarefa
---

**Responsável:** Pessoa
**Sprint:** 1 / 2 / 3 / 4
**Prazo:**

## O que precisa ser entregue
- [ ]
- [ ]

## Onde vai ficar
<!-- Ex.: assets/imagens/, textos/, js/modulos/ -->

## Quem vai revisar
