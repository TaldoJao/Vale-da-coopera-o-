## O que mudou
<!-- Em uma ou duas frases. -->

## Tarefa relacionada
Fecha #

## Quem fez
- [ ] Pessoa 1 (arte)  - [ ] Pessoa 2 (texto)  - [ ] Pessoa 3 (código)  - [ ] Pessoa 4 (som/teste)

## Antes de pedir revisão
- [ ] Mexi só nas pastas da minha área (ou avisei quem é dono)
- [ ] Nomes de arquivo em minúsculo, sem espaço e sem acento
- [ ] Testei no navegador / ouvi o som / li o texto
- [ ] Não subi senha, chave de API nem arquivo gigante

## Como testar
<!-- Ex.: abrir o index.html, clicar em "Pular vez" com 3 jogadores. -->

## Print ou observação (opcional)
