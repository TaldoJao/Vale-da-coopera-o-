# Como contribuir

Regra de ouro: **a `main` sempre tem que funcionar.** Ninguém commita direto nela. Todo trabalho passa por branch, Pull Request (PR) e revisão.

## Quem mexe em quê

| Pessoa | Área | Pastas |
|---|---|---|
| 1 | Arte e identidade visual | `assets/imagens/` |
| 2 | História e conteúdo | `textos/` |
| 3 | Programação e integração | `js/`, `css/`, `index.html`, `sw.js` |
| 4 | Sons, testes e apresentação | `assets/sons/`, `docs/testes/`, `docs/` |

Precisa mexer na pasta de outra pessoa? Avisa no grupo e marca ela como revisora do PR.

## Fluxo de cada tarefa

1. Pega uma tarefa em **Issues** e coloca seu nome nela.
2. Atualiza a `main` e cria sua branch (nome abaixo).
3. Trabalha em commits pequenos.
4. Sobe a branch e abre um **Pull Request** usando o modelo que aparece.
5. **Outra pessoa revisa** (nunca você mesmo). Só vale com pelo menos 1 aprovação.
6. A **Pessoa 3 faz o merge**. A **Pessoa 4 testa** o resultado no site publicado.
7. Apaga a branch e fecha a tarefa.

Os comandos passo a passo estão no [GUIA-GIT.md](GUIA-GIT.md).

## Nome das branches

Formato `area/o-que-e-isso`, tudo minúsculo e com hífen:

- `arte/personagens`, `arte/mapa`
- `texto/eventos`, `texto/biografias`
- `codigo/pular-vez`, `codigo/modo-offline`
- `teste/relatorio-sprint-2`, `teste/sons`
- `docs/manual`

## Mensagem de commit

Curta, no imperativo, dizendo **o que** mudou:

- `Adiciona botão de pular vez`
- `Corrige reconexão quando a sala expira`
- `Inclui retratos da Lia e do Theo`

Evite `ajustes`, `teste`, `asdf`, `final2`.

## Arquivos

- Nomes em **minúsculo, sem espaço e sem acento**: `vila-0.png`, não `Vila 0.PNG`. O GitHub barra o PR se o nome estiver fora do padrão.
- Imagens em PNG, sons em MP3 ou OGG. Siga os tamanhos do documento da turma.
- Se for trocar um arquivo, mantenha o **mesmo nome**, pra não quebrar o jogo.
- Nada de arquivos enormes (vídeo bruto, projetos do editor). Isso fica no Drive do grupo.
- **Nunca** suba senha, chave de API ou arquivo `.env`.

## Como revisar um PR

- [ ] Abre o site de teste do PR ou roda local: funciona?
- [ ] Os nomes dos arquivos seguem o padrão?
- [ ] O texto tem erro de português ou passa do limite de caracteres?
- [ ] O PR só mexe no que a descrição diz?
- Comenta o que achou. Se estiver tudo certo, clica em **Approve**.

## Conflitos

Aconteceu conflito? Calma, é normal. Siga a seção "Resolver conflito" do [GUIA-GIT.md](GUIA-GIT.md) ou chame a Pessoa 3.

## Travou?

Pede ajuda no grupo antes de tentar "resolver" com `git push --force`. Esse comando pode apagar o trabalho dos outros.
