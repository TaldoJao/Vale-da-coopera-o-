# Vale da Cooperação

Jogo cooperativo de estratégia pra navegador (HTML/CSS/JS). Este repositório tem os módulos da Pessoa 3: programação e integração.

## Como rodar

Os módulos usam `import`, então abrir o `index.html` com duplo clique não funciona. Use um servidor local:

- VS Code: extensão **Live Server** → botão direito no `index.html` → *Open with Live Server*
- ou no terminal: `python3 -m http.server 8000` e abre `http://localhost:8000`

Pra testar com os 4 celulares, publica no **GitHub Pages** (Settings → Pages → branch `main`).

## Estrutura

```
index.html            página principal (demo)
sw.js                 modo offline (cache dos arquivos)
css/style.css         estilos
js/main.js            liga os módulos na tela (parte de demo)
js/modulos/
  store.js            armazenamento (trocar aqui quando escolher o banco)
  salas.js            criar/salvar sala e limpar salas antigas (24h)
  jogo.js             turnos: pular vez, desconectar, reconectar
  sessao.js           lembra quem sou eu pra reconectar depois de F5
  imagens.js          imagens com emoji de reserva se o arquivo falhar
  sons.js             efeitos sonoros + botão de silenciar
  cronometro.js       cronômetro opcional por vez
  offline.js          fila de ações feitas sem internet
assets/imagens/       PNGs da Pessoa 1 (nomes em js/modulos/imagens.js)
assets/sons/          sons da Pessoa 4 (nomes em js/modulos/sons.js)
textos/               história e textos da Pessoa 2
docs/                 manual do jogo e relatórios de teste
scripts/              configuração do GitHub (uso único)
.github/              modelos de PR/tarefa, revisores e automações
```

## Pendências

- [ ] Trocar o `Store` pelo banco real
- [ ] Inserir a história e os textos da Pessoa 2
- [ ] Colocar as imagens e os sons nas pastas `assets/`
- [ ] Modo plateia (só se sobrar tempo)

## Contribuindo

Leia o [CONTRIBUTING.md](CONTRIBUTING.md) (regras do grupo) e o [GUIA-GIT.md](GUIA-GIT.md) (comandos passo a passo). Resumo: ninguém commita na `main`, cada tarefa tem uma branch, e todo PR é revisado por outra pessoa.

Quem configura o repositório pela primeira vez (Pessoa 3) usa o `scripts/configurar-github.sh`.
