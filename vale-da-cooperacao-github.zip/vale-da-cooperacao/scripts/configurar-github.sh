#!/usr/bin/env bash
# Roda UMA vez, pela Pessoa 3, dentro da pasta do projeto.
# Precisa do Git e do GitHub CLI (https://cli.github.com) logado: gh auth login
set -e
REPO_NOME="vale-da-cooperacao"
VISIBILIDADE="--private"   # troque por --public se o grupo quiser

git init -b main
git add .
git commit -m "Estrutura inicial do projeto"
gh repo create "$REPO_NOME" $VISIBILIDADE --source=. --remote=origin --push
REPO=$(gh repo view --json nameWithOwner -q .nameWithOwner)

# Etiquetas
gh label create tarefa  --color 3b6b3f --description "Entrega do projeto" --force
gh label create bug     --color 8a3322 --description "Problema encontrado" --force
gh label create arte    --color 9c5a2b --force
gh label create texto   --color 523d5c --force
gh label create codigo  --color 2f5570 --force
gh label create teste   --color 2d5a55 --force
for s in 1 2 3 4; do gh label create "sprint-$s" --color e0a82e --force; done

# GitHub Pages publicado pelo Actions
gh api -X POST "repos/$REPO/pages" -f build_type=workflow >/dev/null 2>&1 || true

# Protege a main: só entra por PR com 1 aprovação.
# (Em repositório privado de conta gratuita isso pode falhar. Sem problema:
#  a regra do grupo continua valendo.)
gh api -X PUT "repos/$REPO/branches/main/protection" --input - <<'JSON' || echo "Proteção da main não disponível neste plano. Seguir a regra no grupo."
{
  "required_status_checks": {"strict": false, "contexts": ["checar"]},
  "enforce_admins": false,
  "required_pull_request_reviews": {"required_approving_review_count": 1},
  "restrictions": null
}
JSON

echo "Pronto! Agora convide as outras 3 pessoas em Settings > Collaborators."
echo "Site: https://$(echo $REPO | cut -d/ -f1).github.io/$REPO_NOME/"
