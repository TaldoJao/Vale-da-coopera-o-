# Guia de Git pro grupo

Não curte terminal? Dá pra fazer quase tudo com o **GitHub Desktop** (desktop.github.com) ou pelo próprio site do GitHub. Os comandos abaixo valem pra quem usa o terminal.

## 1. Primeira vez

```bash
git config --global user.name "Seu Nome"
git config --global user.email "seu-email-do-github@exemplo.com"
git clone https://github.com/USUARIO/vale-da-cooperacao.git
cd vale-da-cooperacao
```

## 2. Começar uma tarefa

```bash
git checkout main
git pull
git checkout -b arte/personagens     # troque pelo nome da sua branch
```

## 3. Salvar o trabalho

```bash
git status                           # vê o que mudou
git add assets/imagens/lia.png       # adiciona só o que é seu
git commit -m "Inclui retrato da Lia"
```

Evite `git add .` sem olhar o `git status` antes: dá pra subir arquivo sem querer.

## 4. Mandar pro GitHub e abrir o PR

```bash
git push -u origin arte/personagens
```

O GitHub mostra um botão **Compare & pull request**. Clica, preenche o modelo e marca uma pessoa pra revisar.

## 5. Mantém sua branch em dia

Se a `main` andou enquanto você trabalhava:

```bash
git checkout main
git pull
git checkout arte/personagens
git merge main
```

## 6. Resolver conflito

O Git avisa `CONFLICT` e marca o arquivo assim:

```
<<<<<<< HEAD
a sua versão
=======
a versão que veio da main
>>>>>>> main
```

1. Abre o arquivo, escolhe o que fica (ou junta os dois) e apaga as linhas `<<<<<<<`, `=======` e `>>>>>>>`.
2. `git add arquivo-resolvido`
3. `git commit` (pode deixar a mensagem padrão)
4. `git push`

Ficou em dúvida? Para e chama a Pessoa 3.

## 7. Errei, e agora?

| Situação | Comando |
|---|---|
| Quero descartar mudanças ainda **não commitadas** num arquivo | `git restore arquivo` |
| Fiz `git add` sem querer | `git restore --staged arquivo` |
| Errei a mensagem do último commit (ainda **não subi**) | `git commit --amend -m "Nova mensagem"` |
| Commitei na `main` por engano (ainda **não subi**) | avisa a Pessoa 3 antes de mexer |

## 8. Sem terminal (pelo site)

Pra subir só uma imagem ou texto: no GitHub, abre a pasta certa → **Add file → Upload files**. Na hora de salvar, escolhe **Create a new branch** e abre o PR. Funciona bem pra artistas e pra quem escreve os textos.

## 9. Testar o site publicado

Depois do merge, o GitHub publica sozinho em `https://USUARIO.github.io/vale-da-cooperacao/` (leva 1 a 2 minutos). É nesse link que a Pessoa 4 testa nos 4 celulares.
